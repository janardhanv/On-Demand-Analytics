#!/bin/bash
#rm -r /home/hduser/check
mkdir /home/hduser/check
