#!/bin/bash
export VAR="$(ifconfig eth0 | sed -n '/inet /{s/.*addr://;s/ .*//;p}')"
#sudo chmod 777 -R /usr/local
#cp framework_zips/* /usr/local
#install_scripts/*.sh
DIR="$( cd -P "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
/bin/rm /usr/local/make
echo -e "$DIR\n$USER@$VAR" > /usr/local/make
#add other details of tomcat server etc
tar xzvf $DIR/apache-tomcat-7.0.30.tar.gz -C $DIR
rm -rf /usr/local/tomcat/*
mv $DIR/apache-tomcat-7.0.30/* /usr/local/tomcat
rm -r $DIR/apache-tomcat-7.0.30
export CATALINA_HOME=/usr/local/tomcat
#sudo iptables -t nat -A OUTPUT -d localhost -p tcp --dport 80 -j REDIRECT --to-ports 8080
#sudo iptables -t nat -A OUTPUT -d $VAR -p tcp --dport 80 -j REDIRECT --to-ports 8080
cp $DIR/*.jar /usr/local/tomcat/lib/
cp $DIR/*.war /usr/local/tomcat/webapps/
/usr/local/tomcat/bin/startup.sh
