#!/bin/bash
cd /usr/local/giraph
mvn compile
mvn test
