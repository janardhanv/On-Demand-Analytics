#!/bin/bash
cp zips/* /usr/local
install_scripts/Hadoop.sh
install_scripts/Mahout.sh
install_scripts/RHadoop.sh
install_scripts/Giraph.sh
