#!/bin/bash
cd giraph
mvn compile
mvn test
