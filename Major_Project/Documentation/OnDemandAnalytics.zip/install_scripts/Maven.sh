#!/bin/bash
cd /usr/local/maven
mvn clean install
